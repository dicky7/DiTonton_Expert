//movie routes
const POPULAR_MOVIES_ROUTE = '/popular-movie';
const TOP_RATED_MOVIE_ROUTE = '/top-rated-movie';
const MOVIE_DETAIL_ROUTE = '/movie_detail';
const SEARCH_ROUTE = '/search';
const ABOUT_ROUTE = '/about';

//tv routes
const POPULAR_TV_ROUTE = "/popular_tv";
const TOP_RATED_TV_ROUTE = '/top-rated-tv';
const TV_ON_AIR_ROUTE = "/tv_on_air";
const TV_DETAIL_ROUTE = '/tv_detail';