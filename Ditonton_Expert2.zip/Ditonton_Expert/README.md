# Status Badge
[![Codemagic build status](https://api.codemagic.io/apps/63843c488d8edee564809083/63843c488d8edee564809082/status_badge.svg)](https://codemagic.io/apps/63843c488d8edee564809083/63843c488d8edee564809082/latest_build)
